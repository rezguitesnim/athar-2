
import { GoogleGenAI, GenerateContentResponse, Type } from "@google/genai";
import { AnalysisResult } from "../types";

export class GeminiService {
  private getClient() {
    return new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async analyzeInscription(base64Image: string): Promise<AnalysisResult> {
    const ai = this.getClient();
    const model = 'gemini-3-flash-preview';
    
    const prompt = `
      As a Senior Epigrapher and World-Class Linguistic Expert, provide a DEFINITIVE, RIGOROUS, and UNIQUE analysis of this specific inscription.
      
      CRITICAL: Focus exclusively on the details visible in THIS specific image. Avoid any canned or generic descriptions. 
      If the text is damaged, describe the damage. If the script shows regional variations, highlight them.
      The analysis must be academic, profound, and unique to this artifact.
    `;

    try {
      const response: GenerateContentResponse = await ai.models.generateContent({
        model: model,
        contents: { 
          parts: [
            { inlineData: { mimeType: 'image/jpeg', data: base64Image } },
            { text: prompt }
          ] 
        },
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              detectedLanguage: { type: Type.STRING },
              scriptType: { type: Type.STRING },
              transliteration: { type: Type.STRING },
              rawText: { type: Type.STRING },
              translations: {
                type: Type.OBJECT,
                properties: {
                  ar: { type: Type.STRING },
                  en: { type: Type.STRING },
                  fr: { type: Type.STRING }
                },
                required: ["ar", "en", "fr"]
              },
              linguisticAnalyses: {
                type: Type.OBJECT,
                properties: {
                  ar: { type: Type.STRING },
                  en: { type: Type.STRING },
                  fr: { type: Type.STRING }
                },
                required: ["ar", "en", "fr"]
              },
              historicalContexts: {
                type: Type.OBJECT,
                properties: {
                  ar: { type: Type.STRING },
                  en: { type: Type.STRING },
                  fr: { type: Type.STRING }
                },
                required: ["ar", "en", "fr"]
              },
              confidence: { type: Type.NUMBER }
            },
            required: ["detectedLanguage", "scriptType", "rawText", "translations", "linguisticAnalyses", "historicalContexts", "confidence"]
          },
          temperature: 0.4,
          seed: Math.floor(Math.random() * 1000000),
          thinkingConfig: { thinkingBudget: 1500 }
        },
      });

      const text = response.text;
      if (!text) throw new Error("Empty response from AI");
      return JSON.parse(text) as AnalysisResult;
    } catch (error) {
      console.error("Gemini Analysis Failure:", error);
      throw error;
    }
  }

  async generateSpeech(text: string, lang: 'ar' | 'en' | 'fr'): Promise<string> {
    const ai = this.getClient();
    const voice = lang === 'ar' ? 'Kore' : lang === 'en' ? 'Puck' : 'Charon';
    
    try {
      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: `Read with perfect academic intonation in ${lang}: ${text}` }] }],
        config: {
          responseModalities: ["AUDIO"],
          speechConfig: {
            voiceConfig: {
              prebuiltVoiceConfig: { voiceName: voice },
            },
          },
        },
      });

      return response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data || '';
    } catch (error) {
      console.error("Gemini TTS Failure:", error);
      throw error;
    }
  }
}
