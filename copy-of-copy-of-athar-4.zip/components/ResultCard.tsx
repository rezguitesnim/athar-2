
import React, { useState, useEffect, useCallback } from 'react';
import { AnalysisResult } from '../types';
import { readTranslation, stopSpeech } from '../speech';

interface ResultCardProps {
  result: AnalysisResult;
  imageUrl: string;
  uiLang: 'ar' | 'en' | 'fr';
}

const CARD_STRINGS = {
  ar: {
    title: "تقرير الاستدلال اللغوي",
    verified: "تحليل بنيوي معتمد",
    scientific: "الترجمة الأكاديمية",
    historical: "السياق التاريخي",
    analysis: "منطق فك الشفرة",
    references: "المعجم والمراجع",
    inferredScript: "اللغة والخط المستنتج",
    script: "نوع الخط",
    confidence: "دقة الذكاء الاصطناعي",
    listen: "استمع للترجمة"
  },
  en: {
    title: "Linguistic Inference Report",
    verified: "CERTIFIED STRUCTURAL ANALYSIS",
    scientific: "Academic Translation",
    historical: "Historical Context",
    analysis: "Deciphering Logic",
    references: "Lexicon & References",
    inferredScript: "Inferred Script & Language",
    script: "Script",
    confidence: "AI Confidence",
    listen: "Listen to translation"
  },
  fr: {
    title: "Rapport d'Inférence Linguistique",
    verified: "ANALYSE STRUCTURELLE CERTIFIÉE",
    scientific: "Traduction Académique",
    historical: "Contexte Historique",
    analysis: "Logique de Déحiffrement",
    references: "Lexique et Références",
    inferredScript: "Écriture et Langue Déduites",
    script: "Écriture",
    confidence: "Confiance de l'IA",
    listen: "Écouter la traduction"
  }
};

export const ResultCard: React.FC<ResultCardProps> = ({ result, uiLang }) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const t = CARD_STRINGS[uiLang];

  const translation = result.translations[uiLang];
  const analysis = result.linguisticAnalyses[uiLang];
  const context = result.historicalContexts[uiLang];

  useEffect(() => {
    return () => {
      stopSpeech();
      setIsPlaying(false);
      setIsGenerating(false);
    };
  }, [result]);

  const handleToggleSpeech = useCallback(async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (isPlaying || isGenerating) {
      stopSpeech();
      setIsPlaying(false);
      setIsGenerating(false);
    } else {
      setIsGenerating(true);
      // Wait for async TTS generation and playback
      await readTranslation(
        translation, 
        uiLang, 
        () => {
          setIsGenerating(false);
          setIsPlaying(true);
        }, 
        () => {
          setIsGenerating(false);
          setIsPlaying(false);
        }
      );
    }
  }, [isPlaying, isGenerating, translation, uiLang]);

  const getScriptClass = (lang: string | undefined) => {
    if (!lang) return '';
    const l = lang.toLowerCase();
    if (l.includes('أمازيغ') || l.includes('tifinagh')) return 'amazigh-text';
    if (l.includes('هيرو') || l.includes('hieroglyph')) return 'hieroglyphic-text';
    return '';
  };

  return (
    <div className="section-card animate-fade-up">
      <div className="flex justify-between items-center mb-8 pb-6 border-b border-white/5">
        <div>
          <h3 className="text-secondary font-serif-arabic text-3xl m-0 flex items-center gap-4">
            <i className="fas fa-feather-pointed"></i>
            {t.title}
          </h3>
          <p className="text-[10px] text-emerald-500 font-bold uppercase tracking-[0.3em] mt-3 flex items-center gap-2">
            <i className="fas fa-check-circle"></i>
            {t.verified}
          </p>
        </div>
        <button 
           onClick={handleToggleSpeech} 
           disabled={isGenerating && !isPlaying}
           className={`w-14 h-14 rounded-full flex items-center justify-center transition-all cursor-pointer z-20 shadow-xl ${
             isPlaying ? 'bg-secondary text-dark scale-110' : 
             isGenerating ? 'bg-amber-500/20 text-secondary animate-pulse' : 
             'bg-white/5 text-secondary hover:bg-white/10 active:scale-95'
           }`}
           title={t.listen}
        >
           {isGenerating ? (
             <i className="fas fa-circle-notch animate-spin text-xl"></i>
           ) : (
             <i className={`fas ${isPlaying ? 'fa-stop' : 'fa-volume-up'} text-xl`}></i>
           )}
        </button>
      </div>

      <div className="space-y-10">
        <div className="text-center py-10 bg-black/60 rounded-[2.5rem] border border-secondary/10 shadow-xl">
          <div className="text-[10px] text-secondary/40 uppercase font-black tracking-widest mb-6">{t.inferredScript}</div>
          <div className={`text-4xl font-bold mb-6 ${getScriptClass(result.detectedLanguage)}`}>
            {result.detectedLanguage}
          </div>
          {result.transliteration && (
            <div className="text-lg font-mono text-amber-500/80 bg-amber-500/5 inline-block px-8 py-3 rounded-2xl border border-amber-500/20">
              [ {result.transliteration} ]
            </div>
          )}
        </div>

        <div className="p-12 bg-secondary/5 rounded-[2.5rem] border border-secondary/20 relative shadow-inner">
          <i className="fas fa-quote-right absolute top-6 right-8 text-7xl opacity-5"></i>
          <p className="text-3xl md:text-5xl font-serif-arabic text-amber-50 leading-relaxed text-center italic">
            "{translation}"
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="p-8 bg-white/2 rounded-3xl border border-white/5">
            <h4 className="text-secondary text-xs font-black uppercase mb-6 flex items-center gap-3 tracking-widest">
              <i className="fas fa-brain"></i>
              {t.analysis}
            </h4>
            <p className="text-sm text-light/70 leading-loose italic">
              {analysis}
            </p>
          </div>
          <div className="p-8 bg-white/2 rounded-3xl border border-white/5">
            <h4 className="text-secondary text-xs font-black uppercase mb-6 flex items-center gap-3 tracking-widest">
              <i className="fas fa-landmark"></i>
              {t.historical}
            </h4>
            <p className="text-sm text-light/70 leading-loose">
              {context}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap gap-4 pt-6 border-t border-white/5">
           <div className="px-5 py-2 rounded-full bg-secondary/10 border border-secondary/20 text-[10px] text-secondary font-bold uppercase tracking-widest">
             {t.script}: {result.scriptType}
           </div>
           <div className="px-5 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-[10px] text-emerald-400 font-bold uppercase tracking-widest">
             {t.confidence}: {Math.round(result.confidence * 100)}%
           </div>
        </div>
      </div>
    </div>
  );
};
