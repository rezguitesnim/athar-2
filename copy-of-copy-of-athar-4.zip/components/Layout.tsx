
import React from 'react';

interface LayoutProps {
  children: React.ReactNode;
  lang: 'ar' | 'en' | 'fr';
  onLangChange: (l: 'ar' | 'en' | 'fr') => void;
}

const HEADER_TEXT = {
  ar: { title: "أثـــر", tagline: "مختبر فك رموز النقوش الأثرية بالذكاء الاصطناعي" },
  en: { title: "ATHAR", tagline: "A.I. Powered Ancient Inscription Deciphering Lab" },
  fr: { title: "ATHAR", tagline: "Laboratoire de Déchiffrement d'Inscriptions par l'IA" }
};

const LANGUAGES = [
  { code: 'ar', native: 'عربي', label: 'Arabic' },
  { code: 'en', native: 'EN', label: 'English' },
  { code: 'fr', native: 'FR', label: 'French' }
];

export const Layout: React.FC<LayoutProps> = ({ children, lang, onLangChange }) => {
  const t = HEADER_TEXT[lang];

  return (
    <div className="container">
      <nav className="lang-nav">
        {LANGUAGES.map((l) => (
          <button
            key={l.code}
            onClick={() => onLangChange(l.code as any)}
            className={`lang-btn ${lang === l.code ? 'active' : ''}`}
          >
            <span>{l.native}</span>
          </button>
        ))}
      </nav>

      <header className="animate-fade-up">
        <div className="logo-icon">
          <i className="fas fa-scroll"></i>
        </div>
        <h1>{t.title}</h1>
        <p className="tagline">{t.tagline}</p>
      </header>

      <main>{children}</main>

      <footer>
        &copy; {new Date().getFullYear()} ATHAR INTELLIGENCE • DECODING HISTORY
      </footer>
    </div>
  );
};
